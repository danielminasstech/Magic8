//
//  Model.h
//  Magic8
//
//  Created by Daniel on 5/11/16.
//  Copyright © 2016 Daniel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property(nonatomic) NSMutableArray *answers;
-(NSString *)returnAnswer;
@end
