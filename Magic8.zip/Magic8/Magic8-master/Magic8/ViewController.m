//
//  ViewController.m
//  Magic8
//
//  Created by Daniel on 5/11/16.
//  Copyright © 2016 Daniel. All rights reserved.
//

#import "ViewController.h"
#import "Model.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    aModel = [[Model alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnAnswer:(id)sender {
    _lblText.text = [aModel returnAnswer];
}

@end
