//
//  Model.m
//  Magic8
//
//  Created by Daniel on 5/11/16.
//  Copyright © 2016 Daniel. All rights reserved.
//

#import "Model.h"

@implementation Model

-(NSString *)returnAnswer
{
    if([_answers count] == 0)
    {
        _answers = [[NSMutableArray alloc] init];
        [_answers addObject: @"It is certain"];
        [_answers addObject: @"It is decidedly so"];
        [_answers addObject: @"Without a doubt"];
        [_answers addObject: @"Yes, definitely"];
        [_answers addObject: @"You may rely on it"];
        [_answers addObject: @"As I see it, yes"];
        [_answers addObject: @"Most likely"];
        [_answers addObject: @"Outlook good"];
        [_answers addObject: @"Yes"];
        [_answers addObject: @"Signs point to yes"];
        [_answers addObject: @"Reply hazy try again"];
        [_answers addObject: @"Ask again later"];
        [_answers addObject: @"Better not tell you now"];
        [_answers addObject: @"Cannot predict now"];
        [_answers addObject: @"Concentrate and ask again"];
        [_answers addObject: @"Don't count on it"];
        [_answers addObject: @"My reply is no"];
        [_answers addObject: @"My sources say no"];
        [_answers addObject: @"Outlook not so good"];
        [_answers addObject: @"Very doubtful"];
    }
    int r = rand() % 20;
    NSString *tmp = [_answers objectAtIndex:r];
    return tmp;
}


@end
