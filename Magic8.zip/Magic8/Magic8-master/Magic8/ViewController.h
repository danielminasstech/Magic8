//
//  ViewController.h
//  Magic8
//
//  Created by Daniel on 5/11/16.
//  Copyright © 2016 Daniel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Model.h"

@interface ViewController : UIViewController
{
    Model *aModel;
}

@property (weak, nonatomic) IBOutlet UILabel *lblText;
@end

